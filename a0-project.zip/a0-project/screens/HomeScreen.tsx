import { View, Text, StyleSheet, TouchableOpacity, Dimensions, ScrollView, Animated } from 'react-native';
import { useState, useRef, useEffect } from 'react';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');
const BUTTON_SIZE = Math.min((width - 80) / 4, 80);

interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: Date;
}

export default function CalculatorScreen() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  
  const slideAnim = useRef(new Animated.Value(width)).current;
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: showHistory ? 0 : width,
      useNativeDriver: true,
      tension: 100,
      friction: 8,
    }).start();
  }, [showHistory]);

  const getCurrentOperation = () => {
    if (previousValue !== null && operation && !waitingForNewValue) {
      return `${previousValue} ${operation} ${display} =`;
    } else if (previousValue !== null && operation) {
      return `${previousValue} ${operation}`;
    }
    return '';
  };

  const addToHistory = (expression: string, result: string) => {
    const newItem: HistoryItem = {
      id: Date.now().toString(),
      expression,
      result,
      timestamp: new Date(),
    };
    setHistory(prev => [newItem, ...prev].slice(0, 20));
  };

  const animateButton = () => {
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const inputNumber = (num: string) => {
    animateButton();
    if (waitingForNewValue) {
      setDisplay(num);
      setWaitingForNewValue(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const inputOperation = (nextOperation: string) => {
    animateButton();
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);
      setDisplay(String(newValue));
      setPreviousValue(newValue);
    }

    setWaitingForNewValue(true);
    setOperation(nextOperation);
  };

  const calculate = (firstValue: number, secondValue: number, operation: string) => {
    switch (operation) {
      case '+':
        return firstValue + secondValue;
      case '-':
        return firstValue - secondValue;
      case '×':
        return firstValue * secondValue;
      case '÷':
        return secondValue !== 0 ? firstValue / secondValue : 0;
      default:
        return secondValue;
    }
  };

  const performCalculation = () => {
    animateButton();
    const inputValue = parseFloat(display);

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation);
      const expression = `${previousValue} ${operation} ${inputValue}`;
      const result = String(newValue);
      
      addToHistory(expression, result);
      setDisplay(result);
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  const clear = () => {
    animateButton();
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const toggleSign = () => {
    animateButton();
    const currentValue = parseFloat(display);
    setDisplay(String(-currentValue));
  };

  const percentage = () => {
    animateButton();
    const currentValue = parseFloat(display);
    setDisplay(String(currentValue / 100));
  };

  const inputDecimal = () => {
    animateButton();
    if (waitingForNewValue) {
      setDisplay('0.');
      setWaitingForNewValue(false);
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.');
    }
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const Button = ({ onPress, title, style, textStyle, glowColor, isLarge = false }: {
    onPress: () => void;
    title: string;
    style?: any;
    textStyle?: any;
    glowColor?: string;
    isLarge?: boolean;
  }) => (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <TouchableOpacity
        style={[
          styles.button, 
          style,
          isLarge && styles.largeButton
        ]}
        onPress={onPress}
        activeOpacity={0.7}
      >
        <BlurView intensity={25} style={[styles.buttonBlur, style, isLarge && styles.largeButton]}>
          {glowColor && (
            <View style={[styles.glow, { backgroundColor: glowColor, shadowColor: glowColor }]} />
          )}
          <Text style={[styles.buttonText, textStyle]}>{title}</Text>
        </BlurView>
      </TouchableOpacity>
    </Animated.View>
  );

  return (
    <LinearGradient
      colors={['#0a0a0a', '#1a1a1a', '#2a2a2a']}
      style={styles.container}
    >
      {/* Main Calculator */}
      <View style={styles.calculatorContainer}>
        {/* Display Area */}
        <BlurView intensity={30} style={styles.displayContainer}>
          <LinearGradient
            colors={['rgba(255,255,255,0.05)', 'rgba(255,255,255,0.02)']}
            style={styles.displayGradient}
          >
            {/* Secondary Display */}
            <Text style={styles.secondaryDisplay}>
              {getCurrentOperation()}
            </Text>
            
            {/* Main Display */}
            <Text style={styles.displayText} numberOfLines={1} adjustsFontSizeToFit>
              {display}
            </Text>
          </LinearGradient>
        </BlurView>

        {/* Button Grid */}
        <View style={styles.buttonContainer}>
          {/* First Row */}
          <View style={styles.row}>
            <Button onPress={clear} title="C" style={styles.functionButton} textStyle={styles.functionButtonText} />
            <Button onPress={toggleSign} title="±" style={styles.functionButton} textStyle={styles.functionButtonText} />
            <Button onPress={percentage} title="%" style={styles.functionButton} textStyle={styles.functionButtonText} />
            <Button onPress={() => inputOperation('÷')} title="÷" style={styles.operatorButton} textStyle={styles.operatorButtonText} />
          </View>

          {/* Second Row */}
          <View style={styles.row}>
            <Button onPress={() => inputNumber('7')} title="7" />
            <Button onPress={() => inputNumber('8')} title="8" />
            <Button onPress={() => inputNumber('9')} title="9" />
            <Button onPress={() => inputOperation('×')} title="×" style={styles.operatorButton} textStyle={styles.operatorButtonText} />
          </View>

          {/* Third Row */}
          <View style={styles.row}>
            <Button onPress={() => inputNumber('4')} title="4" />
            <Button onPress={() => inputNumber('5')} title="5" />
            <Button onPress={() => inputNumber('6')} title="6" />
            <Button onPress={() => inputOperation('-')} title="−" style={styles.operatorButton} textStyle={styles.operatorButtonText} />
          </View>

          {/* Fourth Row */}
          <View style={styles.row}>
            <Button onPress={() => inputNumber('1')} title="1" />
            <Button onPress={() => inputNumber('2')} title="2" />
            <Button onPress={() => inputNumber('3')} title="3" />
            <Button onPress={() => inputOperation('+')} title="+" style={styles.operatorButton} textStyle={styles.operatorButtonText} />
          </View>

          {/* Fifth Row */}
          <View style={styles.row}>
            <Button onPress={() => inputNumber('0')} title="0" style={styles.zeroButton} />
            <Button onPress={inputDecimal} title="." />
            <Button 
              onPress={performCalculation} 
              title="=" 
              style={styles.equalsButton} 
              textStyle={styles.equalsButtonText}
              glowColor="#007AFF"
            />
          </View>

          {/* History Button */}
          <View style={styles.historyButtonContainer}>
            <Button 
              onPress={() => setShowHistory(!showHistory)}
              title="🕘 History"
              style={styles.historyToggleButton}
              textStyle={styles.historyToggleText}
            />
          </View>
        </View>
      </View>

      {/* History Panel */}
      <Animated.View 
        style={[
          styles.historyPanel, 
          { 
            transform: [{ translateX: slideAnim }] 
          }
        ]}
      >
        <BlurView intensity={40} style={styles.historyBlur}>
          <LinearGradient
            colors={['rgba(0,0,0,0.8)', 'rgba(0,0,0,0.6)']}
            style={styles.historyGradient}
          >
            <View style={styles.historyHeader}>
              <Text style={styles.historyTitle}>🕘 History</Text>
              <View style={styles.historyHeaderButtons}>
                <TouchableOpacity onPress={clearHistory} style={styles.clearHistoryButton}>
                  <Text style={styles.clearHistoryText}>Clear</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setShowHistory(false)} style={styles.closeHistoryButton}>
                  <Text style={styles.closeHistoryText}>✕</Text>
                </TouchableOpacity>
              </View>
            </View>
            
            <ScrollView style={styles.historyScroll} showsVerticalScrollIndicator={false}>
              {history.length === 0 ? (
                <View style={styles.emptyHistoryContainer}>
                  <Text style={styles.emptyHistoryText}>No calculations yet</Text>
                  <Text style={styles.emptyHistorySubtext}>Your calculation history will appear here</Text>
                </View>
              ) : (
                history.map((item, index) => (
                  <TouchableOpacity
                    key={item.id}
                    style={[styles.historyItem, { opacity: 1 - (index * 0.05) }]}
                    onPress={() => {
                      setDisplay(item.result);
                      setShowHistory(false);
                    }}
                    activeOpacity={0.7}
                  >
                    <BlurView intensity={10} style={styles.historyItemBlur}>
                      <Text style={styles.historyExpression}>{item.expression}</Text>
                      <Text style={styles.historyResult}>= {item.result}</Text>
                      <Text style={styles.historyTime}>
                        {item.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </Text>
                    </BlurView>
                  </TouchableOpacity>
                ))
              )}
            </ScrollView>
          </LinearGradient>
        </BlurView>
      </Animated.View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
  },
  mainContent: {
    flex: 0.7,
    paddingTop: 60,
    paddingLeft: 20,
    paddingRight: 10,
  },
  displayContainer: {
    height: height * 0.25,
    marginBottom: 30,
    borderRadius: 25,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  displayGradient: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    paddingHorizontal: 25,
    paddingBottom: 25,
  },
  displayText: {
    fontSize: 56,
    fontWeight: '200',
    color: '#ffffff',
    textAlign: 'right',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  buttonContainer: {
    flex: 1,
    paddingBottom: 40,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  button: {
    width: BUTTON_SIZE,
    height: BUTTON_SIZE,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  buttonBlur: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  glow: {
    position: 'absolute',
    width: '80%',
    height: '80%',
    borderRadius: 15,
    opacity: 0.3,
    shadowOpacity: 0.8,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 0 },
    elevation: 10,
  },
  buttonText: {
    fontSize: 24,
    fontWeight: '400',
    color: '#ffffff',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    zIndex: 1,
  },
  functionButton: {
    borderColor: 'rgba(166,166,166,0.3)',
  },
  functionButtonText: {
    color: '#a6a6a6',
    fontWeight: '500',
  },
  operatorButton: {
    borderColor: 'rgba(255,149,0,0.3)',
  },
  operatorButtonText: {
    color: '#ff9500',
    fontWeight: '500',
  },
  equalsButton: {
    borderColor: 'rgba(0,122,255,0.3)',
  },
  equalsButtonText: {
    color: '#007AFF',
    fontWeight: '600',
    fontSize: 28,
  },
  zeroButton: {
    width: BUTTON_SIZE * 2 + 15,
  },
  historyPanel: {
    flex: 0.3,
    marginTop: 60,
    marginRight: 20,
    marginBottom: 40,
    borderRadius: 25,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  historyGradient: {
    flex: 1,
    padding: 20,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  historyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#ffffff',
  },
  clearHistoryButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  clearHistoryText: {
    color: '#ff6b6b',
    fontSize: 14,
    fontWeight: '500',
  },
  historyScroll: {
    flex: 1,
  },
  emptyHistoryText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 50,
    fontStyle: 'italic',
  },
  historyItem: {
    marginBottom: 12,
    borderRadius: 15,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  historyItemBlur: {
    padding: 15,
  },
  historyExpression: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    marginBottom: 4,
  },
  historyResult: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '500',
  },
});